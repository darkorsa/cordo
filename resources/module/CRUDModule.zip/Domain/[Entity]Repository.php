<?php declare(strict_types=1);

namespace App\[Context]\[Entities]\Domain;

interface [Entity]Repository
{
    public function add([Entity] $[entity]) : void;

    public function update([Entity] $[entity]) : void;

    public function delete([Entity] $[entity]) : void;
}
