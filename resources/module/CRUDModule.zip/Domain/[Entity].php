<?php

declare(strict_types=1);

namespace App\[Context]\[Entities]\Domain;

use DateTime;

class [Entity]
{
    private $id;

    private $isActive;

    private $createdAt;

    private $updatedAt;

    public function __construct(
        string $id
    ) {
        $this->id = $id;
        $this->isActive = 1;
        $this->createdAt = new DateTime();
        $this->updatedAt = new DateTime();
    }

    public function update(bool $isActive)
    {
        $this->isActive = (int) $isActive;
        $this->updatedAt = new DateTime();
    }
}
