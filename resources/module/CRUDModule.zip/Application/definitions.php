<?php

use App\[Context]\[Entities]\Domain\[Entity]Repository;
use App\[Context]\[Entities]\Application\Service\[Entity]QueryService;
use App\[Context]\[Entities]\Infrastructure\Persistance\Doctrine\Query\[Entity]DoctrineQuery;
use App\[Context]\[Entities]\Infrastructure\Persistance\Doctrine\ORM\[Entity]DoctrineRepository;

return [
    [Entity]Repository::class => DI\autowire([Entity]DoctrineRepository::class),
    [Entity]QueryService::class => DI\create([Entity]QueryService::class)
        ->constructor(DI\get([Entity]DoctrineQuery::class)),
];
