<?php

use App\[Context]\[Entities]\Application\Service\[Entity]QueryService;
use App\[Context]\[Entities]\Application\Command\Handler\Delete[Entity]Handler;
use App\[Context]\[Entities]\Application\Command\Handler\Update[Entity]Handler;
use App\[Context]\[Entities]\Application\Command\Handler\CreateNew[Entity]Handler;
use App\[Context]\[Entities]\Infrastructure\Persistance\Doctrine\Query\[Entity]DoctrineQuery;
use App\[Context]\[Entities]\Infrastructure\Persistance\Doctrine\ORM\[Entity]DoctrineRepository;

return [
    CreateNew[Entity]Handler::class => DI\create()
        ->constructor(DI\get([Entity]DoctrineRepository::class), DI\get('emitter')),
    Update[Entity]Handler::class => DI\create()
        ->constructor(DI\get([Entity]DoctrineRepository::class), DI\get('emitter')),
    Delete[Entity]Handler::class => DI\create()
        ->constructor(DI\get([Entity]DoctrineRepository::class), DI\get('emitter')),
    '[context].[entities].query.service' => DI\create([Entity]QueryService::class)
        ->constructor(DI\get([Entity]DoctrineQuery::class)),
];
