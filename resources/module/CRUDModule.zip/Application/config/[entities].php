<?php

return [
    'limit' => 25,
];
