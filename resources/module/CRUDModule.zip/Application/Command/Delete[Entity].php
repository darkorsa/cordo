<?php declare(strict_types=1);

namespace App\[Context]\[Entities]\Application\Command;

class Delete[Entity] extends CreateNew[Entity]
{
}
