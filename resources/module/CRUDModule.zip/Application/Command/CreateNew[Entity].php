<?php declare(strict_types=1);

namespace App\[Context]\[Entities]\Application\Command;

use DateTime;

class CreateNew[Entity]
{
    private $isActive;

    private $createdAt;

    private $updatedAt;

    public function __construct(
        int $isActive,
        DateTime $createdAt,
        DateTime $updatedAt
    ) {
        $this->isActive = $isActive;
        $this->createdAt = $createdAt;
        $this->updatedAt = $updatedAt;
    }

    public function isActive(): int
    {
        return $this->isActive;
    }

    public function createdAt(): DateTime
    {
        return $this->createdAt;
    }

    public function updatedAt(): DateTime
    {
        return $this->updatedAt;
    }
}
