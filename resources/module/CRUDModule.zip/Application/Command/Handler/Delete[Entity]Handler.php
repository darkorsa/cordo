<?php

declare(strict_types=1);

namespace App\[Context]\[Entities]\Application\Command\Handler;

use App\[Context]\[Entities]\Domain\[Entity];
use League\Event\EmitterInterface;
use App\[Context]\[Entities]\Domain\[Entity]Repository;
use App\[Context]\[Entities]\Application\Command\Delete[Entity];

class Delete[Entity]Handler
{
    private $[entities];

    private $emitter;

    public function __construct([Entity]Repository $[entities], EmitterInterface $emitter)
    {
        $this->[entities] = $[entities];
        $this->emitter = $emitter;
    }

    public function __invoke(Delete[Entity] $command): void
    {
        $[entity] = $this->[entities]->find($command->id);

        $this->[entities]->delete($[entity]);
    }
}
