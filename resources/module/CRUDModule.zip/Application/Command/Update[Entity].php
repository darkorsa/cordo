<?php

declare(strict_types=1);

namespace App\[Context]\[Entities]\Application\Command;

class Update[Entity]
{
    private $id;

    private $isActive;

    public function __construct(string $id, bool $isActive)
    {
        $this->id = $id;
        $this->isActive = $isActive;
    }

    public function getId(): string
    {
        return $this->id;
    }

    public function getIsActive(): bool
    {
        return $this->isActive;
    }
}
