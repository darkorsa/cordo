<?php

declare(strict_types=1);

namespace App\[Context]\[Entities]\Application\Command;

class Update[Entity]
{
   public function __construct(
    public readonly string $id,
    public readonly bool $isActive
) {}
}
