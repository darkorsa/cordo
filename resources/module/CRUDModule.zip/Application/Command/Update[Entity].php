<?php

declare(strict_types=1);

namespace App\[Context]\[Entities]\Application\Command;

class Update[Entity]
{
    //
}
