<?php

declare(strict_types=1);

namespace App\[Context]\[Entities]\Application\Service;

use App\[Context]\[Entities]\Application\Query\[Entity]View;
use App\[Context]\[Entities]\Application\Query\[Entity]Query;
use App\[Context]\[Entities]\Application\Query\[Entity]Filter;
use Doctrine\Common\Collections\ArrayCollection;

class [Entity]QueryService
{
    private $[entity]Query;

    public function __construct([Entity]Query $[entity]Query)
    {
        $this->[entity]Query = $[entity]Query;
    }

    public function getOneById(string $id, ?[Entity]Filter $[entity]Filter = null): [Entity]View
    {
        return $this->[entity]Query->getById($id, $[entity]Filter);
    }

    public function getCollection(?[Entity]Filter $[entity]Filter = null): ArrayCollection
    {
        return $this->[entity]Query->getAll($[entity]Filter);
    }

    public function getCount(?[Entity]Filter $[entity]Filter = null): int
    {
        return $this->[entity]Query->count($[entity]Filter);
    }
}
