<?php

declare(strict_types=1);

namespace App\[Context]\[Entities]\Application\Service;

use Cordo\Core\Application\Query\QueryFilter;
use Doctrine\Common\Collections\ArrayCollection;
use Cordo\Core\Application\Query\QueryFilterInterface;
use App\[Context]\[Entities]\Application\Query\[Entity]View;
use App\[Context]\[Entities]\Application\Query\[Entity]Query;

class [Entity]QueryService
{
    private $[entity]Query;

    public function __construct([Entity]Query $[entity]Query)
    {
        $this->[entity]Query = $[entity]Query;
    }

    public function getOneById(string $id, ?QueryFilterInterface $queryFilter = null): [Entity]View
    {
        $[entity]Filter = $queryFilter ?: new QueryFilter();
        $[entity]Filter->addFilter('id', $id);
        
        return $this->[entity]Query->getOne($[entity]Filter);
    }

    public function getCollection(?QueryFilterInterface $queryFilter = null): ArrayCollection
    {
        return $this->[entity]Query->getAll($queryFilter);
    }

    public function getCount(?QueryFilterInterface $queryFilter = null): int
    {
        return $this->[entity]Query->count($queryFilter);
    }
}
