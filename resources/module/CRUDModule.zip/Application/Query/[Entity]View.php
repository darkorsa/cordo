<?php

declare (strict_types=1);

namespace App\[Context]\[Entities]\Application\Query;

use DateTime;

class [Entity]View
{
    private string $id;

    private bool $isActive;

    private DateTime $createdAt;

    private DateTime $updatedAt;

    public function __construct(
        string $id,
        bool $isActive,
        DateTime $createdAt,
        DateTime $updatedAt
    ) {
        $this->id = $id;
        $this->isActive = $isActive;
        $this->createdAt = $createdAt;
        $this->updatedAt = $updatedAt;
    }

    public static function fromArray(array $data): [Entity]View
    {
        return new [Entity]View(
            $data['id_[entity]'],
            (bool) $data['is_active'],
            new DateTime($data['created_at']),
            new DateTime($data['updated_at'])
        );
    }

    public function id(): string
    {
        return $this->id;
    }

    public function isActive(): bool
    {
        return $this->isActive;
    }

    public function createdAt(): DateTime
    {
        return $this->createdAt;
    }

    public function updatedAt(): DateTime
    {
        return $this->updatedAt;
    }
}
