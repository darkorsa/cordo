<?php

declare (strict_types=1);

namespace App\[Context]\[Entities]\Application\Query;

use DateTimeImmutable;

class [Entity]View
{
    public function __construct(
        public readonly string $id,
        public readonly bool $isActive,
        public readonly DateTimeImmutable $createdAt,
        public readonly DateTimeImmutable $updatedAt,
    )
    {
    }
    
    public static function fromArray(array $data): self
    {
        return new self(
            $data['id_[entity]'],
            (bool )$data['is_active'],
            new DateTimeImmutable($data['created_at']),
            new DateTimeImmutable($data['updated_at'])
        );
    }
}
