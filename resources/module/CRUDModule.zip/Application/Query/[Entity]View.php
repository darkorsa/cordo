<?php

declare (strict_types=1);

namespace App\[Context]\[Entities]\Application\Query;

use DateTimeImmutable;

class [Entity]View
{
    private $id;

    private $isActive;

    private $createdAt;

    private $updatedAt;

    public function __construct(
        string $id,
        bool $isActive,
        DateTimeImmutable $createdAt,
        DateTimeImmutable $updatedAt
    )
    {
        $this->id = $id;
        $this->isActive = $isActive;
        $this->createdAt = $createdAt;
        $this->updatedAt = $updatedAt; 
    }
    
    public static function fromArray(array $data): self
    {
        return new self(
            $data['id_[entity]'],
            (bool )$data['is_active'],
            new DateTimeImmutable($data['created_at']),
            new DateTimeImmutable($data['updated_at'])
        );
    }

    public function getId(): string
    {
        return $this->id;
    }

    public function getIsActive(): bool
    {
        return $this->isActive;
    }

    public function getCreatedAt(): DateTimeImmutable
    {
        return $this->createdAt;
    }

    public function getUpdatedAt(): DateTimeImmutable
    {
        return $this->updatedAt;
    }
}
