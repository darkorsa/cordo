<?php

declare (strict_types=1);

namespace App\[Context]\[Entities]\Application\Query;

use DateTime;

class [Entity]View
{
    private $id;

    private $isActive;

    private $createdAt;

    private $updatedAt;

    public function __construct(
        string $id,
        int $isActive,
        DateTime $createdAt,
        DateTime $updatedAt
    ) {
        $this->id = $id;
        $this->isActive = $isActive;
        $this->createdAt = $createdAt;
        $this->updatedAt = $updatedAt;
    }

    public static function fromArray(array $[entity]Data): [Entity]View
    {
        return new [Entity]View(
            $[entity]Data['id_[entity]'],
            (int) $[entity]Data['is_active'],
            new DateTime($[entity]Data['created_at']),
            new DateTime($[entity]Data['updated_at'])
        );
    }

    public function id(): string
    {
        return $this->id;
    }

    public function isActive(): int
    {
        return $this->isActive;
    }

    public function createdAt(): DateTime
    {
        return $this->createdAt;
    }

    public function updatedAt(): DateTime
    {
        return $this->updatedAt;
    }
}
