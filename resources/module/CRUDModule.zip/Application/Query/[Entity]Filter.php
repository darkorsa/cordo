<?php declare (strict_types=1);

namespace App\[Entities]\Application\Query;

class [Entity]Filter
{
    private $offset;

    private $limit;

    private $isActive;

    public function setActive(bool $isActive): [Entity]Filter
    {
        $this->isActive = (int) $isActive;

        return $this;
    }

    public function setOffset(int $offset) : [Entity]Filter
    {
        $this->offset = $offset;

        return $this;
    }

    public function setLimit(int $limit) : [Entity]Filter
    {
        $this->limit = $limit;

        return $this;
    }

    public function getOffset(): ?int
    {
        return $this->offset;
    }

    public function getLimit(): ?int
    {
        return $this->limit;
    }

    public function getIsActive(): ?int
    {
        return $this->isActive;
    }
}
