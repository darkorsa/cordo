<?php

namespace App\[Context]\[Entities]\Application\Query;

use Doctrine\Common\Collections\ArrayCollection;

interface [Entity]Query
{
    public function count(?[Entity]Filter $[entity]Filter = null): int;

    public function getById(string $[entity]Id, ?[Entity]Filter $[entity]Filter = null): [Entity]View;

    public function getAll(?[Entity]Filter $[entity]Filter = null): ArrayCollection;
}
