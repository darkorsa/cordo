<?php

namespace App\[Context]\[Entities]\Application\Query;

use Doctrine\Common\Collections\ArrayCollection;
use Cordo\Core\Application\Query\QueryFilterInterface;

interface [Entity]Query
{
    public function count(?QueryFilterInterface $queryFilter = null): int;

    public function getOne(QueryFilterInterface $queryFilter): [Entity]View;

    public function getAll(?QueryFilterInterface $queryFilter = null): ArrayCollection;
}
