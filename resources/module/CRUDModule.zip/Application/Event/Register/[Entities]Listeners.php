<?php

declare(strict_types=1);

namespace App\[Entities]\Application\Event\Register;

use Cordo\Core\Application\Service\Register\ListenersRegister;

class [Entities]Listeners extends ListenersRegister
{
    public function register(): void
    {
        
    }
}
