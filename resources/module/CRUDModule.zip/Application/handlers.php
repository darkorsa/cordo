<?php

use App\[Entities]\Application\Command\Delete[Entity];
use App\[Entities]\Application\Command\Update[Entity];
use App\[Entities]\Application\Command\CreateNew[Entity];
use App\[Entities]\Application\Command\Send[Entity]WelcomeMessage;
use App\[Entities]\Application\Command\Handler\Delete[Entity]Handler;
use App\[Entities]\Application\Command\Handler\Update[Entity]Handler;
use App\[Entities]\Application\Command\Handler\CreateNew[Entity]Handler;
use App\[Entities]\Application\Command\Handler\Send[Entity]WelcomeMessageHandler;

return [
    CreateNew[Entity]::class            => CreateNew[Entity]Handler::class,
    Update[Entity]::class               => Update[Entity]Handler::class,
    Delete[Entity]::class               => Delete[Entity]Handler::class,
];
