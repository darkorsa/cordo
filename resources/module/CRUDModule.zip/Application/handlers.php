<?php

use App\[Context]\[Entities]\Application\Command\Delete[Entity];
use App\[Context]\[Entities]\Application\Command\Update[Entity];
use App\[Context]\[Entities]\Application\Command\CreateNew[Entity];
use App\[Context]\[Entities]\Application\Command\Handler\Delete[Entity]Handler;
use App\[Context]\[Entities]\Application\Command\Handler\Update[Entity]Handler;
use App\[Context]\[Entities]\Application\Command\Handler\CreateNew[Entity]Handler;

return [
    CreateNew[Entity]::class => CreateNew[Entity]Handler::class,
    Update[Entity]::class => Update[Entity]Handler::class,
    Delete[Entity]::class => Delete[Entity]Handler::class,
];
