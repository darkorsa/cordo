<?php declare(strict_types=1);

namespace App\[Context]\[Entities]\Infrastructure\Persistance\Doctrine\ORM;

use App\[Context]\[Entities]\Domain\[Entity];
use Doctrine\ORM\EntityManager;
use App\[Context]\[Entities]\Domain\[Entity]Repository;

class [Entity]DoctrineRepository implements [Entity]Repository
{
    private $entityManager;

    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    public function add([Entity] $[entity]): void
    {
        $this->entityManager->persist($[entity]);
        $this->entityManager->flush();
    }

    public function update([Entity] $[entity]): void
    {
        $this->entityManager->merge($[entity]);
        $this->entityManager->flush();
    }

    public function delete([Entity] $[entity]): void
    {
        $entity = $this->entityManager->merge($[entity]);

        $this->entityManager->remove($entity);
        $this->entityManager->flush();
    }
}
