<?php

namespace App\[Context]\[Entities]\Infrastructure\Persistance\Doctrine\Query;

use Doctrine\DBAL\Query\QueryBuilder;
use App\[Context]\[Entities]\Application\Query\[Entity]Filter;
use Cordo\Core\Infractructure\Persistance\Doctrine\Query\QueryFilter;

class [Entity]DoctrineFilter implements QueryFilter
{
    private $[entity]Filter;

    public function __construct(?[Entity]Filter $[entity]Filter)
    {
        $this->[entity]Filter = $[entity]Filter;
    }

    public function filter(QueryBuilder $queryBuilder): void
    {
        if (is_null($this->[entity]Filter)) {
            return;
        }

        if (!is_null($this->[entity]Filter->getIsActive())) {
            $queryBuilder->andWhere('u.is_active', $this->[entity]Filter->getIsActive());
        }

        if (!is_null($this->[entity]Filter->getOffset()) && !is_null($this->[entity]Filter->getLimit())) {
            $queryBuilder->setFirstResult($this->[entity]Filter->getOffset());
            $queryBuilder->setMaxResults($this->[entity]Filter->getLimit());
        }
    }
}
