<?php

declare (strict_types=1);

namespace App\[Context]\[Entities]\Infrastructure\Persistance\Doctrine\Query;

use Doctrine\DBAL\Query\QueryBuilder;
use Cordo\Core\Infractructure\Persistance\Doctrine\Query\QueryBuilderFilter;

class [Entity]DoctrineFilter extends QueryBuilderFilter
{
    public function doFilter(QueryBuilder $queryBuilder): void
    {
        if ($this->getFilter('id') !== null) {
            $queryBuilder
                ->andWhere('ouuid_to_uuid(u.id_[entity]) = :[entity]Id')
                ->setParameter('[entity]Id', $this->queryFilter->getFilter('id'));
        }
    }
}
