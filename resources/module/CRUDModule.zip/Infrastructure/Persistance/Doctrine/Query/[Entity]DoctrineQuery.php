<?php

declare(strict_types=1);

namespace App\[Context]\[Entities]\Infrastructure\Persistance\Doctrine\Query;

use Doctrine\DBAL\Query\QueryBuilder;
use Doctrine\Common\Collections\ArrayCollection;
use App\[Context]\[Entities]\Application\Query\[Entity]View;
use App\[Context]\[Entities]\Application\Query\[Entity]Query;
use App\[Context]\[Entities]\Application\Query\[Entity]Filter;
use Cordo\Core\Infractructure\Persistance\Doctrine\Query\BaseQuery;

class [Entity]DoctrineQuery extends BaseQuery implements [Entity]Query
{
    public function count(?[Entity]Filter $[entity]Filter = null): int
    {
        $queryBuilder = $this->createQB();
        $queryBuilder
            ->select('count(u.id_[entity])')
            ->from('[entity]', 'u');

        return (int) $this->column($queryBuilder, new [Entity]DoctrineFilter($[entity]Filter));
    }

    public function getOne([Entity]Filter $[entity]Filter): [Entity]View
    {
        return $this->getOneByQuery($this->createQB());
    }

    public function getById(string $[entity]Id, ?[Entity]Filter $[entity]Filter = null): [Entity]View
    {
        $queryBuilder = $this->createQB();
        $queryBuilder
            ->where('ouuid_to_uuid(u.id_[entity]) = :[entity]Id')
            ->setParameter('[entity]Id', $[entity]Id);

        $[entity]Data = $this->assoc($queryBuilder, new [Entity]DoctrineFilter($[entity]Filter));

        return [Entity]View::fromArray($[entity]Data);
    }

    public function getAll(?[Entity]Filter $[entity]Filter = null): ArrayCollection
    {
        $queryBuilder = $this->createQB();
        $queryBuilder
            ->select('u.*')
            ->addSelect('ouuid_to_uuid(u.id_[entity]) as id_[entity]')
            ->from('[entity]', 'u');

        $[entities]Data = $this->all($queryBuilder, new [Entity]DoctrineFilter($[entity]Filter));

        $collection = new ArrayCollection();
        array_map(static function (array $[entity]Data) use ($collection) {
            $collection->add([Entity]View::fromArray($[entity]Data));
        }, $[entities]Data);

        return $collection;
    }

    private function getOneByQuery(QueryBuilder $queryBuilder, [Entity]Filter $[entity]Filter = null): [Entity]View
    {
        $queryBuilder = $this->createQB();
        $queryBuilder
            ->select('u.*')
            ->addSelect('ouuid_to_uuid(u.id_[entity]) as id_[entity]')
            ->from('[entity]', 'u');

        $[entity]Data = $this->assoc($queryBuilder, new [Entity]DoctrineFilter($[entity]Filter));

        return [Entity]View::fromArray($[entity]Data);
    }
}
