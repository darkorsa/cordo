<?php

use App\[Entities]\Application\Service\[Entity]ervice;
use App\[Entities]\Application\Command\Handler\Delete[Entity]Handler;
use App\[Entities]\Application\Command\Handler\Update[Entity]Handler;
use App\[Entities]\Application\Command\Handler\CreateNew[Entity]Handler;
use App\[Entities]\Infrastructure\Persistance\Doctrine\Query\[Entity]DoctrineQuery;
use App\[Entities]\Infrastructure\Persistance\Doctrine\ORM\[Entity]DoctrineRepository;

return [
    CreateNew[Entity]Handler::class => DI\create()
        ->constructor(DI\get([Entity]DoctrineRepository::class), DI\get('emitter')),
    Update[Entity]Handler::class => DI\create()
        ->constructor(DI\get([Entity]DoctrineRepository::class), DI\get('emitter')),
    Delete[Entity]Handler::class => DI\create()
        ->constructor(DI\get([Entity]DoctrineRepository::class), DI\get('emitter')),
    [Entity]Service::class => DI\create()
        ->constructor(DI\get([Entity]DoctrineQuery::class)),
];
