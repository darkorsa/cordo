<?php declare(strict_types=1);

namespace App\[Entities]\Application\Command\Handler;

use App\[Entities]\Domain\[Entity];
use League\Event\EmitterInterface;
use App\[Entities]\Domain\[Entity]Repository;
use App\[Entities]\Application\Command\Update[Entity];

class Update[Entity]Handler
{
    private $[entities];

    private $emitter;

    public function __construct([Entity]Repository $[entities], EmitterInterface $emitter)
    {
        $this->[entities] = $[entities];
        $this->emitter = $emitter;
    }

    public function handle(Update[Entity] $command): void
    {
        $[entity] = new [Entity](
            $command->id(),
            $command->isActive(),
            $command->createdAt(),
            $command->updatedAt()
        );

        $this->[entities]->update($[entity]);
    }
}
