<?php declare(strict_types=1);

namespace App\[Entities]\Application\Command;

class Update[Entity] extends CreateNew[Entity]
{
}
