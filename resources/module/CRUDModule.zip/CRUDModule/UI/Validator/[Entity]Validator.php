<?php

namespace App\[Entities]\UI\Validator;

use Particle\Validator\Validator;
use Particle\Validator\ValidationResult;

trait [Entity]Validator
{
    private function validate(array $params): ValidationResult
    {
        $validator = new Validator();

        return $validator->validate($params);
    }
}
