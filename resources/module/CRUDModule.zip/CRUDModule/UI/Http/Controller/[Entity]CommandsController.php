<?php

namespace App\[Entities]\UI\Http\Controller;

use DateTime;
use Ramsey\Uuid\Uuid;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use App\[Entities]\Application\Command\Delete[Entity];
use App\[Entities]\Application\Command\Update[Entity];
use System\UI\Http\Controller\BaseController;
use App\[Entities]\Application\Service\[Entity]Service;
use App\[Entities]\Application\Command\CreateNew[Entity];
use App\[Entities]\UI\Validator\[Entity]Validator;

class [Entity]CommandsController extends BaseController
{
    use [Entity]Validator;

    public function createAction(ServerRequestInterface $request): ResponseInterface
    {
        $params = (array) $request->getParsedBody();

        $result = $this->validate($params, true);

        if (!$result->isValid()) {
            return $this->respondBadRequestError($result->getMessages());
        }

        $params = (object) $params;

        $command = new CreateNew[Entity](
            (string) Uuid::uuid4(),
            (int) false,
            new DateTime(),
            new DateTime()
        );

        $this->commandBus->handle($command);

        return $this->respondWithSuccess();
    }

    public function updateAction(ServerRequestInterface $request): ResponseInterface
    {
        $[entity]Id = $request->getAttribute('[entity]_id');

        $params = (array) $request->getParsedBody();

        $result = $this->validate($params);

        if (!$result->isValid()) {
            return $this->respondBadRequestError($result->getMessages());
        }

        $[entity] = $this->container->get([Entity]Service::class)->getOneById($[entity]Id);

        $params = (object) $params;

        $command = new Update[Entity](
            $[entity]->id(),
            $[entity]->isActive(),
            $[entity]->createdAt(),
            new DateTime()
        );

        $this->commandBus->handle($command);

        return $this->respondWithSuccess();
    }

    public function deleteAction(ServerRequestInterface $request): ResponseInterface
    {
        $[entity]Id = $request->getAttribute('[entity]_id');

        $[entity] = $this->container->get([Entity]Service::class)->getOneById($[entity]Id);

        $command = new Delete[Entity](
            $[entity]->id(),
            $[entity]->isActive(),
            $[entity]->createdAt(),
            $[entity]->updatedAt()
        );

        $this->commandBus->handle($command);

        return $this->respondWithSuccess();
    }
}
