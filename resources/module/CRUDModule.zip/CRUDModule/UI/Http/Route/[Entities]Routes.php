<?php

declare(strict_types=1);

namespace App\Users\UI\Http\Route;

use App\Auth\UI\Http\Middleware\OAuthMiddleware;
use System\Application\Service\Register\RoutesRegister;

class [Entity]Routes extends RoutesRegister
{
    public function register(): void
    {
        $this->router->addRoute(
            'GET',
            '/[entities]',
            'App\[Entities]\UI\Http\Controller\[Entity]QueriesController@index'
        );

        $this->router->addRoute(
            'GET',
            '/[entities]/{id:[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}}',
            'App\[Entities]\UI\Http\Controller\[Entity]QueriesController@get'
        );

        $this->router->addRoute(
            'POST',
            '/[entities]',
            'App\[Entities]\UI\Http\Controller\[Entity]CommandsController@create'
        );

        $this->router->addRoute(
            'PUT',
            '/[entities]',
            'App\[Entities]\UI\Http\Controller\[Entity]CommandsController@update',
            [new OAuthMiddleware($this->container)]
        );

        $this->router->addRoute(
            'DELETE',
            '/[entities]',
            'App\[Entities]\UI\Http\Controller\[Entity]CommandsController@delete',
            [new OAuthMiddleware($this->container)]
        );
    }
}
