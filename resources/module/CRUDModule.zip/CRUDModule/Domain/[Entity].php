<?php declare(strict_types=1);

namespace App\[Entities]\Domain;

use DateTime;
use Assert\Assert;

class [Entity]
{
    private $id;

    private $isActive;

    private $createdAt;

    private $updatedAt;

    public function __construct(
        string $id,
        int $isActive,
        DateTime $createdAt,
        DateTime $updatedAt
    ) {
        // id
        Assert::that($id)
            ->notEmpty()
            ->uuid();
        // isActive
        Assert::that($isActive)
            ->integer()
            ->between(0, 1);

        $this->id = $id;
        $this->isActive = $isActive;
        $this->createdAt = $createdAt;
        $this->updatedAt = $updatedAt;
    }
}
