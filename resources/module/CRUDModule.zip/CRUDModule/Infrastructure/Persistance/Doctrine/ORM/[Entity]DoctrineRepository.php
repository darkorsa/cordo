<?php

declare(strict_types=1);

namespace App\[Context]\[Entities]\Infrastructure\Persistance\Doctrine\ORM;

use Doctrine\ORM\EntityManager;
use App\[Context]\[Entities]\Domain\[Entity];
use App\[Context]\[Entities]\Domain\[Entity]Repository;
use Cordo\Core\Application\Exception\ResourceNotFoundException;

class [Entity]DoctrineRepository implements [Entity]Repository
{
    private $entityManager;

    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    public function find(string $id): [Entity]
    {
        /**
         * @var \App\[Context]\[Entity]\Domain\[Entity]|null $[entity]
         */
        $[entity] = $this->entityManager->find([Entity]::class, $id);
        if (!$[entity]) {
            throw new ResourceNotFoundException();
        }

        return $[entity];
    }

    public function findOneBy(string $entity, array $conditions)
    {
        $[entity] = $this->entityManager->getRepository($entity)->findOneBy($conditions);
        if (!$[entity]) {
            throw new ResourceNotFoundException();
        }

        return $[entity];
    }

    public function add([Entity] $[entity]): void
    {
        $this->entityManager->persist($[entity]);
        $this->entityManager->flush();
    }

    public function update([Entity] $[entity]): void
    {
        $this->entityManager->merge($[entity]);
        $this->entityManager->flush();
    }

    public function delete([Entity] $[entity]): void
    {
        $entity = $this->entityManager->merge($[entity]);

        $this->entityManager->remove($entity);
        $this->entityManager->flush();
    }
}
