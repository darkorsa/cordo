<?php

namespace App\[Context]\[Entities]\UI\Transformer;

use League\Fractal\TransformerAbstract;
use App\[Context]\[Entities]\Application\Query\[Entity]View;

class [Entity]Transformer extends TransformerAbstract
{
    public function transform([Entity]View $[entity])
    {
        return [
            'id'                    => $[entity]->id(),
            'modified'              => $[entity]->updatedAt(),
            'links'                 => [],
        ];
    }
}
