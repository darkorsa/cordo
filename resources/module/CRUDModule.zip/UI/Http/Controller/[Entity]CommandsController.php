<?php

declare (strict_types=1);

namespace App\[Context]\[Entities]\UI\Http\Controller;

use DateTime;
use Ramsey\Uuid\Uuid;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use App\[Context]\[Entities]\Application\Command\Delete[Entity];
use App\[Context]\[Entities]\Application\Command\Update[Entity];
use Cordo\Core\UI\Http\Controller\BaseController;
use App\[Context]\[Entities]\Application\Command\CreateNew[Entity];
use App\[Context]\[Entities]\UI\Validator\New[Entity]Validator;
use App\[Context]\[Entities]\UI\Validator\Update[Entity]Validator;
use App\[Context]\[Entities]\Application\Service\[Entity]QueryService;

class [Entity]CommandsController extends BaseController
{
    public function createAction(ServerRequestInterface $request): ResponseInterface
    {
        $params = (array) $request->getParsedBody();

        $validator = new New[Entity]Validator($params);
        
        if ($validator->fails()) {
            return $this->respondBadRequestError($validator->messages()->toArray());
        }

        $params = (object) $params;

        $command = new CreateNew[Entity](
            Uuid::uuid4()->toString()
        );

        $this->commandBus->handle($command);

        return $this->respondWithSuccess();
    }

    public function updateAction(ServerRequestInterface $request): ResponseInterface
    {
        $[entity]Id = $request->getAttribute('[entity]_id');

        $params = (array) $request->getParsedBody();

        $validator = new Update[Entity]Validator($params);
        
        if ($validator->fails()) {
            return $this->respondBadRequestError($validator->messages()->toArray());
        }

        $[entity] = $this->container->get([Entity]QueryService::class)->getOneById($[entity]Id);

        $params = (object) $params;

        $command = new Update[Entity](
            $[entity]->id,
            $params->is_active,
        );

        $this->commandBus->handle($command);

        return $this->respondWithSuccess();
    }

    public function deleteAction(ServerRequestInterface $request): ResponseInterface
    {
        $[entity]Id = $request->getAttribute('[entity]_id');

        $[entity] = $this->container->get([Entity]QueryService::class)->getOneById($[entity]Id);

        $command = new Delete[Entity]($[entity]->id);

        $this->commandBus->handle($command);

        return $this->respondWithSuccess();
    }
}
