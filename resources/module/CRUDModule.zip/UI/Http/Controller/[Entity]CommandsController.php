<?php

namespace App\[Context]\[Entities]\UI\Http\Controller;

use DateTime;
use Ramsey\Uuid\Uuid;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use App\[Context]\[Entities]\Application\Command\Delete[Entity];
use App\[Context]\[Entities]\Application\Command\Update[Entity];
use Cordo\Core\UI\Http\Controller\BaseController;
use App\[Context]\[Entities]\Application\Service\[Entity]Service;
use App\[Context]\[Entities]\Application\Command\CreateNew[Entity];
use App\[Context]\[Entities]\UI\Validator\[Entity]Validator;

class [Entity]CommandsController extends BaseController
{
    public function createAction(ServerRequestInterface $request): ResponseInterface
    {
        $params = (array) $request->getParsedBody();

        $validator = new New[Entity]Validator($params);
        
        if (!$validator->isValid()) {
            return $this->respondBadRequestError($validator->messages());
        }

        $params = (object) $params;

        $command = new CreateNew[Entity](
            (string) Uuid::uuid4(),
            (int) false,
            new DateTime(),
            new DateTime()
        );

        $this->commandBus->handle($command);

        return $this->respondWithSuccess();
    }

    public function updateAction(ServerRequestInterface $request): ResponseInterface
    {
        $[entity]Id = $request->getAttribute('[entity]_id');

        $params = (array) $request->getParsedBody();

        $validator = new Update[Entity]Validator($params);
        
        if (!$validator->isValid()) {
            return $this->respondBadRequestError($validator->messages());
        }

        $[entity] = $this->container->get([Entity]Service::class)->getOneById($[entity]Id);

        $params = (object) $params;

        $command = new Update[Entity](
            $[entity]->id(),
            $[entity]->isActive(),
            $[entity]->createdAt(),
            new DateTime()
        );

        $this->commandBus->handle($command);

        return $this->respondWithSuccess();
    }

    public function deleteAction(ServerRequestInterface $request): ResponseInterface
    {
        $[entity]Id = $request->getAttribute('[entity]_id');

        $[entity] = $this->container->get([Entity]Service::class)->getOneById($[entity]Id);

        $command = new Delete[Entity]($[entity]->id());

        $this->commandBus->handle($command);

        return $this->respondWithSuccess();
    }
}
