<?php

declare(strict_types=1);

namespace App\[Context]\[Entities]\UI\Http\Controller;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Cordo\Core\Application\Query\QueryFilter;
use Cordo\Core\UI\Http\Controller\BaseController;
use App\[Context]\[Entities]\UI\Transformer\[Entity]Transformer;

class [Entity]QueriesController extends BaseController
{
    public function indexAction(ServerRequestInterface $request): ResponseInterface
    {
        $config = $this->container->get('config');
        $queryParams = $request->getQueryParams();

        if (!array_key_exists('offset', $queryParams['page'] ?? [])) {
            $queryParams['page']['offset'] = 0;
        }
        if (!array_key_exists('limit', $queryParams['page'] ?? [])) {
            $queryParams['page']['limit'] = $config->get('[context]_[entities]::[entities].limit');
        }

        $[entity]Filter = QueryFilter::fromQueryParams($queryParams);
        $[entity]Filter->addFilter('active', '1');

        $service = $this->container->get('[context].[entities].query.service');

        $data = $this->transformerManager->transform($service->getCollection($[entity]Filter), '[context]/[entities]');
        $data['total'] = $service->getCount($[entity]Filter);

        return $this->respondWithData($data);
    }

    public function getAction(ServerRequestInterface $request, $params): ResponseInterface
    {
        $service = $this->container->get('[context].[entities].query.service');

        $[entity]Filter = QueryFilter::fromQueryParams($queryParams);
        $[entity]Filter->addFilter('active', '1');

        $result = $service->getOneById($params['id'], $[entity]Filter);

        return $this->respondWithData($this->transformerManager->transform($result, '[context]/[entities]'));
    }

    protected function registerTransformers(): void
    {
        $this->transformerManager->add(new [Entity]Transformer(), '[context]/[entities]');
    }
}
