<?php

declare(strict_types=1);

namespace App\[Context]\[Entities]\UI\Http\Controller;

use Psr\Http\Message\ResponseInterface;
use App\[Context]\[Entities]\Application\Query\[Entity]Filter;
use Psr\Http\Message\ServerRequestInterface;
use App\[Context]\[Entities]\UI\Transformer\[Entity]Transformer;
use Cordo\Core\UI\Http\Controller\BaseController;

class [Entity]QueriesController extends BaseController
{
    public function indexAction(ServerRequestInterface $request): ResponseInterface
    {
        $queryParams = $request->getQueryParams();

        $offset = (int) ($queryParams['offset'] ?? 0);
        $limit  = (int) ($queryParams['limit'] ?? $this->container->get('config')->get('[entity]s.limit'));

        $[entity]Filter = (new [Entity]Filter())
            ->setActive(true)
            ->setOffset($offset)
            ->setLimit($limit);

        $service = $this->container->get('[entities].query.service');

        $data = $this->transformerManager->transform($service->getCollection($[entity]Filter), '[entities]');
        $data['total'] = $service->getCount($[entity]Filter);

        return $this->respondWithData($data);
    }

    public function getAction(ServerRequestInterface $request, $params): ResponseInterface
    {
        $service = $this->container->get('[entities].query.service');

        $[entity]Filter = new [Entity]Filter();
        $[entity]Filter->setActive(true);

        $result = $service->getOneById($params['id'], $[entity]Filter);

        return $this->respondWithData($this->transformerManager->transform($result, '[entities]'));
    }

    protected function registerTransformers(): void
    {
        $this->transformerManager->add(new [Entity]Transformer(), '[entities]');
    }
}
