<?php

declare(strict_types=1);

namespace App\[Context]\[Entities]\UI\Http\Route;

use Cordo\Core\Application\Service\Register\RoutesRegister;

class [Entities]Routes extends RoutesRegister
{
    public function register(): void
    {
        $this->router->addRoute(
            'GET',
            '/[context]/[entities]',
            'App\[Context]\[Entities]\UI\Http\Controller\[Entity]QueriesController@index'
        );

        $this->router->addRoute(
            'GET',
            '/[context]/[entities]/{id:[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}}',
            'App\[Context]\[Entities]\UI\Http\Controller\[Entity]QueriesController@get'
        );

        $this->router->addRoute(
            'POST',
            '/[context]/[entities]',
            'App\[Context]\[Entities]\UI\Http\Controller\[Entity]CommandsController@create'
        );

        $this->router->addRoute(
            'PUT',
            '/[context]/[entities]',
            'App\[Context]\[Entities]\UI\Http\Controller\[Entity]CommandsController@update',
        );

        $this->router->addRoute(
            'DELETE',
            '/[context]/[entities]',
            'App\[Context]\[Entities]\UI\Http\Controller\[Entity]CommandsController@delete',
        );
    }
}
