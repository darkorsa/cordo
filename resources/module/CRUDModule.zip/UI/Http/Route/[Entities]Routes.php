<?php

declare(strict_types=1);

namespace App\[Entities]\UI\Http\Route;

use Cordo\Core\Application\Service\Register\RoutesRegister;

class [Entity]Routes extends RoutesRegister
{
    public function register(): void
    {
        $this->router->addRoute(
            'GET',
            '/[entities]',
            'App\[Context]\[Entities]\UI\Http\Controller\[Entity]QueriesController@index'
        );

        $this->router->addRoute(
            'GET',
            '/[entities]/{id:[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}}',
            'App\[Context]\[Entities]\UI\Http\Controller\[Entity]QueriesController@get'
        );

        $this->router->addRoute(
            'POST',
            '/[entities]',
            'App\[Context]\[Entities]\UI\Http\Controller\[Entity]CommandsController@create'
        );

        $this->router->addRoute(
            'PUT',
            '/[entities]',
            'App\[Context]\[Entities]\UI\Http\Controller\[Entity]CommandsController@update',
        );

        $this->router->addRoute(
            'DELETE',
            '/[entities]',
            'App\[Context]\[Entities]\UI\Http\Controller\[Entity]CommandsController@delete',
        );
    }
}
