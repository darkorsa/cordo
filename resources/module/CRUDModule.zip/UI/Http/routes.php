<?php

use App\Auth\UI\Http\Middleware\OAuth;

$router->addRoute(
    'GET',
    '/[entities]',
    'App\[Entities]\UI\Http\Controller\[Entity]QueriesController@index'
);

$router->addRoute(
    'GET',
    '/[entities]/{id:[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}}',
    'App\[Entities]\UI\Http\Controller\[Entity]QueriesController@get'
);

$router->addRoute(
    'POST',
    '/[entities]',
    'App\[Entities]\UI\Http\Controller\[Entity]CommandsController@create'
);

$router->addRoute(
    'PUT',
    '/[entities]',
    'App\[Entities]\UI\Http\Controller\[Entity]CommandsController@update',
    [new OAuth($container)]
);

$router->addRoute(
    'DELETE',
    '/[entities]',
    'App\[Entities]\UI\Http\Controller\[Entity]CommandsController@delete',
    [new OAuth($container)]
);
