<?php

namespace App\[Context]\[Entities]\UI\Validator;

use Cordo\Core\UI\Validator\AbstractValidator;

class Update[Entity]Validator extends AbstractValidator
{
    protected function validationRules(): void
    {
        //
    }
}
