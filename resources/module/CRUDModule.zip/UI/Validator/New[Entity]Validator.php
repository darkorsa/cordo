<?php

namespace App\[Context]\[Entities]\UI\Validator;

use Cordo\Core\UI\Validator\AbstractValidator;

class New[Entity]Validator extends AbstractValidator
{
    protected function validationRules(): void
    {
        //
    }
}
