<?php

declare (strict_types=1);

namespace App\[Context]\[Entities]\UI\Validator;

use Cordo\Core\UI\Validator\AbstractValidator;

class New[Entity]Validator extends AbstractValidator
{
    protected function rules(): array
    {
        return [];
    }
}
